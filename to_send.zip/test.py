#!/usr/bin/env python2.7
import numpy
import os
import keras
from model import MultiStyleImageNet
from keras.preprocessing.image import ImageDataGenerator, array_to_img, img_to_array, load_img


if __name__ == '__main__':
	print "bilding model."
	model = MultiStyleImageNet((224,224,3), 1)
	print "Done building model."
	print "Compiling model."
	model.compile(loss='binary_crossentropy',
			optimizer='rmsprop',
			metrics=['accuracy'])
	print "Done compiling model."
	print "Creating data generator."
	train_datagen = ImageDataGenerator(
        rescale=1./255,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True)
	train_generator = train_datagen.flow_from_directory('test_data/train',  
							target_size=(224, 224),  
							batch_size=5,
							class_mode='binary') 
	model.fit_generator(train_generator,
				steps_per_epoch=80,
				epochs=10,
				validation_data=train_generator,
				validation_steps=800)
	model.save_weights('test_weights.h5') 

