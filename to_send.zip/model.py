#!/usr/bin/env python2.7
import keras
from keras.layers import Dense, Merge
from keras.models import Model
from keras.layers import Flatten
from keras.layers import Add
from keras.layers import Dense
from keras.layers import Input
from keras.layers import Conv2D
from keras.layers import MaxPooling2D
from keras.layers import GlobalMaxPooling2D
from keras.layers import GlobalAveragePooling2D


def MultiStyleImageNet(input_shape, classes):

	img_input = Input(shape=input_shape)
	#Block 1
	x = Conv2D(64, (3, 3), activation='relu', padding='same', name='block1_conv1')(img_input)
	x = Conv2D(64, (3, 3), activation='relu', padding='same', name='block1_conv2')(x)
	x = MaxPooling2D((2, 2), strides=(2, 2), name='block1_pool')(x)

	#Block 2
	x1 = Conv2D(128, (3, 3), activation='relu', padding='same', name='block2_conv1_a')(x)
	x1 = Conv2D(128, (3, 3), activation='relu', padding='same', name='block2_conv2_a')(x1)
	x1 = MaxPooling2D((2, 2), strides=(2, 2), name='block2_pool_a')(x1)
	x2 = Conv2D(128, (3, 3), activation='relu', padding='same', name='block2_conv1_b')(x)
	x2 = Conv2D(128, (3, 3), activation='relu', padding='same', name='block2_conv2_b')(x2)
	x2 = MaxPooling2D((2, 2), strides=(2, 2), name='block2_pool_b')(x2)

	#Block 3
	x = Add()([x1, x2])
	x = Conv2D(256, (3, 3), activation='relu', padding='same', name='block3_conv1')(x)
	x = Conv2D(256, (3, 3), activation='relu', padding='same', name='block3_conv2')(x)
	x = Conv2D(256, (3, 3), activation='relu', padding='same', name='block3_conv3')(x)
	x = MaxPooling2D((2, 2), strides=(2, 2), name='block3_pool')(x)

	# Block 4
	x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block4_conv1')(x)
	x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block4_conv2')(x)
	x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block4_conv3')(x)
	x = MaxPooling2D((2, 2), strides=(2, 2), name='block4_pool')(x)

	# Block 5
	x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block5_conv1')(x)
	x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block5_conv2')(x)
	x = Conv2D(512, (3, 3), activation='relu', padding='same', name='block5_conv3')(x)
	x = MaxPooling2D((2, 2), strides=(2, 2), name='block5_pool')(x)

	x = Flatten(name='flatten')(x)
	x = Dense(4096, activation='relu', name='fc1')(x)
	x = Dense(4096, activation='relu', name='fc2')(x)
	x = Dense(classes, activation='softmax', name='predictions')(x)

	model = Model(img_input, x, name='MultiStyleImageNet')

	return model

if __name__ == '__main__':
	print "bilding model."
	model = MultiStyleImageNet((224,224,3), 2)
	print "Done building model."
	print "Compiling model."
	model.compile(loss='binary_crossentropy',
			optimizer='rmsprop',
			metrics=['accuracy'])
	print "Done compiling model."
